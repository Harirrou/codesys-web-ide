/* Wispbloom runs entirely in the client (index.html + js/).
 * This minimal rules module satisfies the apps-engine contract for a
 * single-player app; it holds no gameplay state. */
export const meta = {
  name: 'Wispbloom',
  description: 'One-touch orbit-shooter puzzle in a living cosmic garden.',
  minPlayers: 1,
  maxPlayers: 1,
};

export function setup(players) {
  return { players: players || [], startedAt: 0 };
}

export function validateAction(state, playerId, action) {
  return true;
}

export function applyAction(state, playerId, action) {
  return state;
}

export function isGameOver(state) {
  return false;
}

export function viewFor(state, playerId) {
  return state;
}
