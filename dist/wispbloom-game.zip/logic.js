/* Wispbloom is a fully client-side game; this stub satisfies the
 * apps-engine requirement for a rules module at the zip root. */
export function setup() { return {}; }
export function turn(state) { return state; }
